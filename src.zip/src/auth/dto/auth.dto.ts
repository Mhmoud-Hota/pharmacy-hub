// src/auth/dto/auth.dto.ts
import { IsString, IsOptional, MinLength, IsPhoneNumber } from 'class-validator';

export enum OtpMethod { SMS = 'sms', WHATSAPP = 'whatsapp' }

export class RegisterDto {
  @IsString() name: string;
  @IsString() phone: string;
  @IsString() @MinLength(6) password: string;
  @IsOptional() @IsString() profileImage?: string;
  @IsOptional() method?: OtpMethod;
}

export class LoginDto {
  @IsString() phone: string;
  @IsString() password: string;
}

export class SendOtpDto {
  @IsString() phone: string;
  @IsOptional() method?: OtpMethod;
}

export class VerifyOtpDto {
  @IsString() phone: string;
  @IsString() otp: string;
}

export class ResetPasswordDto {
  @IsString() phone: string;
  @IsString() otp: string;
  @IsString() @MinLength(6) newPassword: string;
}