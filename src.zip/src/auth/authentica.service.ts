// // src/auth/authentica.service.ts
// /**
//  * AuthenticaService
//  * ──────────────────
//  * يتعامل مع Authentica API لإرسال والتحقق من OTP.
//  * Docs: https://docs.authentica.sa
//  *
//  * Send OTP  → POST https://api.authentica.sa/api/v2/send-otp
//  * Verify    → POST https://api.authentica.sa/api/v2/verify-otp
//  * Header    → X-Authorization: <api-key>
//  */
// import {
//   Injectable, Logger,
//   ServiceUnavailableException,
// } from '@nestjs/common';
// import { ConfigService } from '@nestjs/config';
// import { OtpMethod }     from './dto/auth.dto';

// const AUTHENTICA_BASE = 'https://api.authentica.sa/api/v2';

// @Injectable()
// export class AuthenticaService {
//   private readonly logger = new Logger(AuthenticaService.name);
//   private readonly apiKey: string;

//   constructor(private readonly config: ConfigService) {
//     this.apiKey = this.config.getOrThrow<string>('AUTHENTICA_API_KEY');
//   }

//   // ── إرسال OTP ──────────────────────────────────────────────────────────────
//   async sendOtp(phone: string, method: OtpMethod = OtpMethod.SMS): Promise<void> {
//     const body: Record<string, any> = { method, phone };

//     const templateId = this.config.get<string>('AUTHENTICA_TEMPLATE_ID');
//     if (templateId) body.template_id = parseInt(templateId, 10);

//     this.logger.log(`[Authentica] Sending OTP → ${phone} via ${method}`);

//     let res: Response;
//     let json: any;

//     try {
//       res  = await fetch(`${AUTHENTICA_BASE}/send-otp`, {
//         method:  'POST',
//         headers: {
//           'Content-Type':    'application/json',
//           'X-Authorization': this.apiKey,
//         },
//         body: JSON.stringify(body),
//       });
//       json = await res.json();
//     } catch (err: any) {
//       const message = err instanceof Error ? err.message : String(err);
//       this.logger.error(`[Authentica] Network error: ${message}`);
//       throw new ServiceUnavailableException('تعذّر الاتصال بخدمة OTP، حاول لاحقاً');
//     }

//     if (!res.ok || !json.success) {
//       this.logger.error(`[Authentica] Send OTP failed (${res.status}): ${JSON.stringify(json)}`);
//       throw new ServiceUnavailableException(
//         json?.message ?? 'فشل إرسال رمز التحقق، حاول مجدداً',
//       );
//     }

//     this.logger.log(`[Authentica] OTP sent successfully → ${phone}`);
//   }

//   // ── التحقق من OTP ───────────────────────────────────────────────────────────
//   async verifyOtp(phone: string, otp: string): Promise<boolean> {
//     this.logger.log(`[Authentica] Verifying OTP for ${phone}`);

//     let res: Response;
//     let json: any;

//     try {
//       res  = await fetch(`${AUTHENTICA_BASE}/verify-otp`, {
//         method:  'POST',
//         headers: {
//           'Content-Type':    'application/json',
//           'X-Authorization': this.apiKey,
//         },
//         body: JSON.stringify({ phone, otp }),
//       });
//       json = await res.json();
//     } catch (err: any) {
//       this.logger.error(`[Authentica] Network error on verify: ${err.message}`);
//       throw new ServiceUnavailableException('تعذّر التحقق من الرمز، حاول لاحقاً');
//     }

//     if (res.status === 401) {
//       this.logger.error('[Authentica] Unauthorized — check AUTHENTICA_API_KEY in .env');
//       throw new ServiceUnavailableException('خطأ في إعدادات نظام التحقق');
//     }

//     this.logger.log(`[Authentica] Verify result for ${phone}: success=${json.success}`);
//     return json.success === true;
//   }
// }
// src/auth/authentica.service.ts

import {
  Injectable,
  Logger,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { OtpMethod } from './dto/auth.dto';
import * as Twilio from 'twilio';

@Injectable()
export class AuthenticaService {
  private readonly logger = new Logger(AuthenticaService.name);
  private readonly client: Twilio.Twilio;
  private readonly verifyServiceSid: string;

  constructor(private readonly config: ConfigService) {
    const accountSid =
      this.config.getOrThrow<string>('TWILIO_ACCOUNT_SID');

    const authToken =
      this.config.getOrThrow<string>('TWILIO_AUTH_TOKEN');

    this.verifyServiceSid =
      this.config.getOrThrow<string>(
        'TWILIO_VERIFY_SERVICE_SID',
      );

    this.client = Twilio(accountSid, authToken);
  }

  // ── إرسال OTP ──────────────────────────────────────────────────────────────
  async sendOtp(
    phone: string,
    method: OtpMethod = OtpMethod.SMS,
  ): Promise<void> {
    try {
      const channel =
        method === OtpMethod.WHATSAPP
          ? 'whatsapp'
          : 'sms';

      this.logger.log(
        `[Twilio] Sending OTP → ${phone} via ${channel}`,
      );

      const result = await this.client.verify.v2
        .services(this.verifyServiceSid)
        .verifications.create({
          to: phone,
          channel: channel as 'sms' | 'whatsapp',
        });

      this.logger.log(
        `[Twilio] OTP sent successfully → ${phone} (${result.status})`,
      );
    } catch (err: any) {
      const message =
        err instanceof Error ? err.message : String(err);

      this.logger.error(
        `[Twilio] Send OTP failed: ${message}`,
      );

      throw new ServiceUnavailableException(
        'فشل إرسال رمز التحقق',
      );
    }
  }

  // ── التحقق من OTP ───────────────────────────────────────────────────────────
  async verifyOtp(
    phone: string,
    otp: string,
  ): Promise<boolean> {
    try {
      this.logger.log(
        `[Twilio] Verifying OTP for ${phone}`,
      );

      const result = await this.client.verify.v2
        .services(this.verifyServiceSid)
        .verificationChecks.create({
          to: phone,
          code: otp,
        });

      const success = result.status === 'approved';

      this.logger.log(
        `[Twilio] Verify result for ${phone}: ${success}`,
      );

      return success;
    } catch (err: any) {
      const message =
        err instanceof Error ? err.message : String(err);

      this.logger.error(
        `[Twilio] Verify failed: ${message}`,
      );

      return false;
    }
  }
}